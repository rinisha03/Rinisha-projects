# Dump file
define	DUMPFILE	"dump.log"
