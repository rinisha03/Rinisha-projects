# Symbolic representation of file types supported by SDAS

define	UNKNOWN_FILE	0
define	IMAGE_FILE	1
define	TABLE_FILE	2
