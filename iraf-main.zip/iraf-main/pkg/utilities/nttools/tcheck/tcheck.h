# TCHECK.H -- Symbolic constants used by tcheck

define SYNTAX		1	# Syntax errors in evexpr

