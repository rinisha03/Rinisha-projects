# WHATFILE.H -- Symbolic constants representing file types

define	IS_UNKNOWN	0
define	IS_IMAGE	1
define	IS_TABLE	2

