# Define the permitted input wcs types
define	RG_WCSLIST	"|physical|world|"

define	RG_PHYSICAL	1
define	RG_WORLD	2

# Define the permitted units
define	RG_UNITLIST	"|hours|native|"
define	RG_UHOURS	1
define	RG_UNATIVE	2

# Define the relationship between the two axes
define	RG_AXEQUAL	1
define	RG_AXSWITCHED	2
define	RG_AXNOTEQUAL	3
