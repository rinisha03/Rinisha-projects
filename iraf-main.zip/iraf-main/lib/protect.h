# PROTECT.H -- Action codes for the fio.protect function.

define	REMOVE_PROTECTION	0
define	SET_PROTECTION		1
define	QUERY_PROTECTION	2
