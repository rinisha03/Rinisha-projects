# Type of features for one dimensional centering.

define	EMISSION	1		# Emission feature
define	ABSORPTION	2		# Absorption feature

define	FTYPES	"|emission|absorption|"	# Types for strdic and clgwrd.
